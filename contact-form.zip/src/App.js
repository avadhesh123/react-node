import { useState, useEffect } from "react";
import "./App.css";
import ContactForm from "./components/ContactForm";
import ContactList from "./components/ContactList";

function App() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setLoading(true);
    fetch("http://localhost:8000/api/v1/contact/getcontacts")
      .then((response) => response.json())
      .then((json) => setContacts(json))
      .finally(() => {
        setLoading(false);
      });
  }, []);
  return (
    <div className="App">
      <div className="App-container">
        <ContactForm />
        <ContactList contacts={contacts} loading={loading} />
      </div>
    </div>
  );
}

export default App;
