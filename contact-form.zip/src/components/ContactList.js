import styles from "./ContactList.module.css";

const ContactList = (props) => {
  let contacts = props.contacts;
  let loading = props.loading;
  console.log(props.contacts);
  return (
    <>
      {loading ? (
        <div>Loading...</div>
      ) : contacts.length === 0 ? (
        <h2> No Contact data</h2>
      ) : (
        <div className={styles.list}>
          <h2>Contacts</h2>
          <table>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
            </tr>
            {contacts.map((contact) => (
              <tr key={contact.id}>
                <td>{contact.first_name}</td>
                <td>{contact.email}</td>
                <td>{contact.phone}</td>
              </tr>
            ))}
          </table>
        </div>
      )}
    </>
  );
};

export default ContactList;
