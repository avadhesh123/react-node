import { useState, useRef } from "react";
import axios from "axios";
import styles from "./ContactForm.module.css";
const ContactForm = () => {
  const [isSubmited, setIsSubmited] = useState(0);
  const [response, setResponse] = useState();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [emailCheck, setEmailCheck] = useState("");
  const country = useRef();
  const phone = useRef();
  const about = useRef();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmited(1);
    const { first_name, last_name, email, country, phone, about } =
      e.target.elements;

    let details = {
      first_name: first_name.value,
      last_name: last_name.value,
      email: email.value,
      country: country.value,
      phone: phone.value,
      about: about.value,
    };

    await axios
      .post("http://localhost:8000/api/v1/contact/create", details)
      .then((response) => {
        // setResponse(response.data);
        console.log(response.data);
      })
      .catch(function (error) {
        console.log(error.message);
        setResponse(error.message);
        //console.log(error);
      });
  };

  console.log("firstName", firstName);
  const firstNameHandler = (e) => {
    setFirstName(e.target.value);
  };
  const lastNameHandler = (e) => {
    setLastName(e.target.value);
  };
  const emailHandler = (e) => {
    setEmail(e.target.value);
    let emailRegex = /[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    if (!emailRegex.test(e.target.value)) {
      setEmailCheck("Email id is not valid");
    } else {
      setEmailCheck("");
    }
  };

  return (
    <div className={styles["form-div"]}>
      <h2> Contact Form</h2>
      <form className={styles["form"]} onSubmit={handleSubmit}>
        <div className={styles.elements}>
          <label htmlFor="first_name">First Name:</label>
          <input
            type="text"
            id="first_name"
            value={firstName}
            onChange={firstNameHandler}
          />
          {isSubmited && firstName === "" ? (
            <label className={styles.error}>Please enter First Name!</label>
          ) : (
            ""
          )}
        </div>
        <div className={styles.elements}>
          <label htmlFor="last_name">Last Name:</label>
          <input
            type="text"
            id="last_name"
            value={lastName}
            onChange={lastNameHandler}
          />
          {isSubmited && lastName === "" ? (
            <label className={styles.error}>Please enter Last Name!</label>
          ) : (
            ""
          )}
        </div>
        <div className={styles.elements}>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={emailHandler}
          />
          {isSubmited && email === "" ? (
            <label className={styles.error}>Please enter Email!</label>
          ) : (
            ""
          )}
          {emailCheck && <label className={styles.error}>{emailCheck}</label>}
        </div>
        <div className={styles.elements}>
          <label htmlFor="country">Country:</label>
          <input type="text" id="country" ref={country} />
        </div>
        <div className={styles.elements}>
          <label htmlFor="phone">Phone:</label>
          <input type="text" id="phone" ref={phone} />
        </div>
        <div className={styles.elements}>
          <label htmlFor="about">About:</label>
          <textarea id="about" rows="3" ref={about} />
        </div>
        <div className={styles.elements}>
          {isSubmited && response === "" ? (
            <label>Form is submited</label>
          ) : (
            <button className={styles.btn} type="submit">
              Submit
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
export default ContactForm;
