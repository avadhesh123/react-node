const sequelize = require("../config/db.config");
const Contact = require("../models/contact.model");
exports.gets = (req, res) => {
  res.send("dddddddddd");
  res.end();
};
exports.getcontacts = (req, res) => {
  Contact.findAll()
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while retrieving project details.",
      });
    });
};
exports.create = (req, res) => {
  const postdata = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    email: req.body.email,
    country: req.body.country,
    phone: req.body.phone,
    about: req.body.about,
  };
  let err = 0;
  if (postdata.first_name === "") {
    err++;
    res.status(500).send({
      error: true,
      message: "Please enter first name.",
    });
  } else if (postdata.last_name === "") {
    err++;
    res.status(500).send({
      error: true,
      message: "Please enter last name.",
    });
  } else if (postdata.email === "") {
    err++;
    res.status(500).send({
      error: true,
      message: "Please enter valid email.",
    });
  }
  if (err === 0) {
    Contact.create(postdata)
      .then((num) => {
        if (num.id != "") {
          res.status(200).send({
            error: false,
            message: "Contact form has been submitted successfully.",
          });
        } else {
          res.status(500).send({
            message: num,
          });
        }
      })
      .then((data) => {
        res.status(200).send(data);
      })
      .catch((err) => {
        res.status(500).send({
          message:
            err.message ||
            "Some error occurred while retrieving project details.",
        });
      });
  }
};
