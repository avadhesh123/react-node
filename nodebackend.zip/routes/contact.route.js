const express = require("express");
const router = express.Router();
const contactController = require(appRoot + "/controllers/contact.controller");

router.post("/create", contactController.create);
router.get("/create", contactController.gets);
router.get("/getcontacts", contactController.getcontacts);

module.exports = router;
