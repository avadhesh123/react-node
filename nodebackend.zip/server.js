const express = require("express");
const app = express();

var bodyParser = require("body-parser");
var cors = require("cors");
var path = require("path");
global.appRoot = path.resolve(__dirname);

//setup the server port
const port = process.env.PORT || 8000;

// Middlewares
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

app.get("/", (req, res) => {
  res.send("Contact");
  res.end();
});

const contactRoutes = require("./routes/contact.route");
app.use("/api/v1/contact", contactRoutes);

app.listen("8000", () => {
  console.log("Server is running..");
});
